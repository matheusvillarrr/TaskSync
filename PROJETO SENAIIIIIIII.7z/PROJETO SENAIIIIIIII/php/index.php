<?php
session_start();
if (!isset($_SESSION["logado"])) {
    header("Location: php/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>TaskSync - Início</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Caminho certo -->
</head>
<body>
<header>Bem-vindo ao TaskSync</header>
<div class="container">
    <h2>Escolha uma opção</h2>
    <a href="php/register.php">Cadastrar Usuário</a>
    <a href="php/tasks.php">Ver Tarefas</a>
    <a href="php/logout.php" class="btn-sair">Sair</a>
</div>
</body>
</html>
