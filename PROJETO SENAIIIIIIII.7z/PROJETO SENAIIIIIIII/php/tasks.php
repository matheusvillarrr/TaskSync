<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Tarefas</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header>Gerenciar Tarefas</header>
<div class="container">
    <h2>Tarefas Existentes</h2>
    <?php
    $result = $conn->query("SELECT t.id, t.titulo, t.status, u.nome FROM tarefas t JOIN usuarios u ON t.usuario_id = u.id");
    while ($row = $result->fetch_assoc()) {
        echo "<p><strong>{$row['titulo']}</strong> - {$row['status']} (Usuário: {$row['nome']})
        <a href='tasks.php?del={$row['id']}' style='color:red;'>Excluir</a></p>";
    }

    if (isset($_GET['del'])) {
        $id = $_GET['del'];
        $conn->query("DELETE FROM tarefas WHERE id = $id");
        header("Location: tasks.php");
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $titulo = $_POST["titulo"];
        $status = $_POST["status"];
        $usuario_id = $_POST["usuario_id"];

        $stmt = $conn->prepare("INSERT INTO tarefas (titulo, status, usuario_id) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $titulo, $status, $usuario_id);

        if ($stmt->execute()) {
            echo "<p>Tarefa adicionada!</p>";
        } else {
            echo "<p>Erro ao adicionar tarefa!</p>";
        }
        $stmt->close();
    }
    ?>

    <h2>Adicionar Nova Tarefa</h2>
    <form method="post">
        Título: <input type="text" name="titulo" required><br>
        Status: 
        <select name="status">
            <option value="pendente">Pendente</option>
            <option value="concluída">Concluída</option>
        </select><br>
        Usuário:
        <select name="usuario_id">
            <?php
            $users = $conn->query("SELECT id, nome FROM usuarios");
            while ($user = $users->fetch_assoc()) {
                echo "<option value='{$user['id']}'>{$user['nome']}</option>";
            }
            ?>
        </select><br>
        <input type="submit" value="Criar Tarefa">
    </form>
    <a href="../index.html">Voltar</a>
</div>
</body>
</html>
