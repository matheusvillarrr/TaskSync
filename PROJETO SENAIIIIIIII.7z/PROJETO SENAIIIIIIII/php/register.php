<?php include("db.php"); ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Usuário</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header>Cadastrar Usuário</header>
<div class="container">
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST["nome"];
        $email = $_POST["email"];

        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email) VALUES (?, ?)");
        $stmt->bind_param("ss", $nome, $email);

        if ($stmt->execute()) {
            echo "<p>Usuário <strong>$nome</strong> cadastrado com sucesso!</p>";
        } else {
            echo "<p>Erro ao cadastrar!</p>";
        }

        $stmt->close();
    }
    ?>
    <form method="post">
        Nome: <input type="text" name="nome" required><br>
        Email: <input type="email" name="email" required><br>
        <input type="submit" value="Cadastrar">
    </form>
    <a href="../login.html" class="btn">Voltar</a>

</div>
</body>
</html>
