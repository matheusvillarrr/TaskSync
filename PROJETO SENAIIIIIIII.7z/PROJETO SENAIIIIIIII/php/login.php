<?php
session_start();

$usuario_correto = "admin@tasksync.com";
$senha_correta = "123456";
$erro = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    if ($email === $usuario_correto && $senha === $senha_correta) {
        $_SESSION["logado"] = true;
        header("Location: ../index.html");
        exit();
    } else {
        $erro = "Email ou senha incorretos!";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login - TaskSync</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header>Login - TaskSync</header>
<div class="container">
    <?php if ($erro): ?>
        <p style="color:red;"><?php echo $erro; ?></p>
    <?php endif; ?>

    <form method="post">
        Email: <input type="email" name="email" required><br>
        Senha: <input type="password" name="senha" required><br>
        <input type="submit" value="Entrar">
    </form>
</div>
</body>
</html>
