CREATE DATABASE IF NOT EXISTS tasksync;
USE tasksync;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100)
);

CREATE TABLE tarefas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255),
    status ENUM('pendente','concluída') DEFAULT 'pendente',
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);
